from adafruit_circuitplayground.express import cpx

while True:
    if cpx.touch_A1:
        print('Touched pad A1')
    if cpx.touch_A2:
        print('Touched pad A2')
    if cpx.touch_A3:
        print('Touched pad A3')
    if cpx.touch_A4:
        print('Touched pad A4')
    if cpx.touch_A5:
        print('Touched pad A5')
    if cpx.touch_A6:
        print('Touched pad A6')
    if cpx.touch_A7:
        print('Touched pad A7')
